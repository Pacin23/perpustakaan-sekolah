# Sistem Informasi Perpustakaan Sekolah — Praktikum PPLG

Project mengikuti spesifikasi modul: PHP Native OOP, PDO, MySQL/MariaDB, enam tabel, session, CSRF, prepared statement, CRUD master, transaksi multi-buku, pengembalian, pembatalan, laporan, dan CSS bersama.

## Struktur
- `database.sql`: database dan enam tabel sesuai modul.
- `config/database.php`: koneksi PDO (sesuaikan host/user/password).
- `app/`: helper, autentikasi, dan service transaksi.
- `includes/`: header/footer bersama.
- `assets/style.css`: CSS responsif tambahan.
- File PHP di root: halaman login, dashboard, master data, transaksi, dan laporan.

## Menjalankan di komputer (XAMPP/Laragon)
1. Ekstrak folder `perpustakaan-sekolah` ke `htdocs` (XAMPP) atau `www` (Laragon).
2. Jalankan Apache dan MySQL/MariaDB.
3. Buka phpMyAdmin, impor `database.sql`.
4. Periksa `config/database.php`; default XAMPP biasanya host `127.0.0.1`, user `root`, password kosong.
5. Jalankan sekali melalui terminal dari root project: `php seed_petugas.php`.
6. Buka `http://localhost/perpustakaan-sekolah/`.
7. Login latihan: **admin** / **Perpus@123**.
8. Setelah akun dibuat, hapus `seed_petugas.php` dan `uji_koneksi.php` dari folder project.

## Catatan penting
- Jangan gunakan password contoh untuk sistem sungguhan.
- Nama tabel/kolom dan relasi database tidak diubah dari modul.
- Pengubahan stok mengikuti jumlah buku yang sedang dipinjam.
- Pengembalian kedua ditolak agar stok tidak bertambah dua kali.
- Pengujian akhir harus dilakukan langsung di lingkungan PHP/MySQL. File project belum dapat diklaim lulus uji runtime sebelum dijalankan di komputer/hosting pengguna.
- Untuk menjalankan PHP + MySQL dari Android, dibutuhkan lingkungan server lokal yang mendukung PHP dan MySQL/MariaDB; editor kode saja tidak cukup.
