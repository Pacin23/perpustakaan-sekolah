<?php
declare(strict_types=1);
require_once __DIR__.'/helpers.php';
final class Auth {
    public static function check(): bool { return isset($_SESSION['petugas']) && is_array($_SESSION['petugas']); }
    public static function currentUser(): ?array { return self::check()?$_SESSION['petugas']:null; }
    public static function login(array $p): void {
        session_regenerate_id(true);
        $_SESSION['petugas']=['id_petugas'=>(int)$p['id_petugas'],'nama_petugas'=>(string)$p['nama_petugas'],'username'=>(string)$p['username'],'peran'=>(string)$p['peran']];
    }
    public static function requireLogin(): void { if(!self::check()){flash_set('error','Silakan masuk terlebih dahulu.');redirect('login.php');} }
    public static function logout(): void {
        $_SESSION=[];
        if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),'',time()-42000,$p['path'],$p['domain'],$p['secure'],$p['httponly']);}
        session_destroy();
    }
}
