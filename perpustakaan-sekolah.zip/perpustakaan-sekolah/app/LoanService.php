<?php
declare(strict_types=1);
final class LoanService {
    public function __construct(private readonly PDO $pdo) {}
    private function isValidDate(string $v): bool { $d=DateTimeImmutable::createFromFormat('!Y-m-d',$v); return $d!==false && $d->format('Y-m-d')===$v; }
    public function createLoan(int $memberId,int $clerkId,string $loanDate,string $dueDate,array $items): int {
        if($memberId<1||$clerkId<1||!$this->isValidDate($loanDate)||!$this->isValidDate($dueDate)||$dueDate<$loanDate||$items===[]) throw new DomainException('Data peminjaman tidak valid.');
        foreach($items as $bookId=>$qty) if((int)$bookId<1||!is_int($qty)||$qty<1) throw new DomainException('Buku dan jumlah harus valid.');
        $this->pdo->beginTransaction();
        try {
            $q=$this->pdo->prepare('SELECT status_anggota FROM anggota WHERE id_anggota=? FOR UPDATE');$q->execute([$memberId]);$m=$q->fetch();
            if(!$m||$m['status_anggota']!=='aktif')throw new DomainException('Anggota tidak ditemukan atau nonaktif.');
            $code='PB-'.date('ymdHis').'-'.random_int(100,999);
            $q=$this->pdo->prepare("INSERT INTO peminjaman(kode_peminjaman,id_anggota,id_petugas,tanggal_pinjam,tanggal_jatuh_tempo,status_peminjaman) VALUES(?,?,?,?,?,'dipinjam')");
            $q->execute([$code,$memberId,$clerkId,$loanDate,$dueDate]);$loanId=(int)$this->pdo->lastInsertId();
            $stock=$this->pdo->prepare("UPDATE buku SET stok_tersedia=stok_tersedia-? WHERE id_buku=? AND status_buku='tersedia' AND stok_tersedia>=?");
            $detail=$this->pdo->prepare('INSERT INTO detail_peminjaman(id_peminjaman,id_buku,jumlah) VALUES(?,?,?)');
            foreach($items as $bookId=>$qty){$stock->execute([$qty,(int)$bookId,$qty]);if($stock->rowCount()!==1)throw new DomainException('Stok buku tidak cukup atau buku nonaktif. Transaksi dibatalkan.');$detail->execute([$loanId,(int)$bookId,$qty]);}
            $this->pdo->commit();return $loanId;
        } catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }
    public function markReturned(int $id): void {
        $this->pdo->beginTransaction();
        try {
            $q=$this->pdo->prepare('SELECT status_peminjaman FROM peminjaman WHERE id_peminjaman=? FOR UPDATE');$q->execute([$id]);$loan=$q->fetch();
            if(!$loan||$loan['status_peminjaman']!=='dipinjam')throw new DomainException('Transaksi tidak ditemukan atau sudah dikembalikan.');
            $q=$this->pdo->prepare('SELECT id_buku,jumlah FROM detail_peminjaman WHERE id_peminjaman=?');$q->execute([$id]);$rows=$q->fetchAll();
            if(!$rows)throw new DomainException('Detail buku tidak ditemukan.');
            $restore=$this->pdo->prepare('UPDATE buku SET stok_tersedia=stok_tersedia+? WHERE id_buku=? AND stok_tersedia+?<=stok_total');
            foreach($rows as $r){$n=(int)$r['jumlah'];$restore->execute([$n,(int)$r['id_buku'],$n]);if($restore->rowCount()!==1)throw new DomainException('Stok tidak konsisten.');}
            $q=$this->pdo->prepare("UPDATE peminjaman SET tanggal_kembali=CURDATE(),status_peminjaman='dikembalikan' WHERE id_peminjaman=? AND status_peminjaman='dipinjam'");$q->execute([$id]);
            if($q->rowCount()!==1)throw new DomainException('Status transaksi berubah.');
            $this->pdo->commit();
        }catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }
    public function cancelLoan(int $id): void {
        $this->pdo->beginTransaction();
        try {
            $q=$this->pdo->prepare('SELECT status_peminjaman FROM peminjaman WHERE id_peminjaman=? FOR UPDATE');$q->execute([$id]);$loan=$q->fetch();
            if(!$loan||$loan['status_peminjaman']!=='dipinjam')throw new DomainException('Hanya transaksi yang masih dipinjam dapat dibatalkan.');
            $q=$this->pdo->prepare('SELECT id_buku,jumlah FROM detail_peminjaman WHERE id_peminjaman=?');$q->execute([$id]);$rows=$q->fetchAll();
            if(!$rows)throw new DomainException('Detail transaksi kosong.');
            $restore=$this->pdo->prepare('UPDATE buku SET stok_tersedia=stok_tersedia+? WHERE id_buku=? AND stok_tersedia+?<=stok_total');
            foreach($rows as $r){$n=(int)$r['jumlah'];$restore->execute([$n,(int)$r['id_buku'],$n]);if($restore->rowCount()!==1)throw new DomainException('Stok tidak konsisten.');}
            $q=$this->pdo->prepare('DELETE FROM detail_peminjaman WHERE id_peminjaman=?');$q->execute([$id]);
            $q=$this->pdo->prepare("DELETE FROM peminjaman WHERE id_peminjaman=? AND status_peminjaman='dipinjam'");$q->execute([$id]);
            if($q->rowCount()!==1)throw new DomainException('Transaksi gagal dibatalkan.');
            $this->pdo->commit();
        }catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }
    public function updateDueDate(int $id,string $due): void {
        if(!$this->isValidDate($due))throw new DomainException('Tanggal jatuh tempo tidak valid.');
        $this->pdo->beginTransaction();
        try{$q=$this->pdo->prepare('SELECT tanggal_pinjam,status_peminjaman FROM peminjaman WHERE id_peminjaman=? FOR UPDATE');$q->execute([$id]);$r=$q->fetch();
            if(!$r||$r['status_peminjaman']!=='dipinjam'||$due<$r['tanggal_pinjam'])throw new DomainException('Transaksi tidak valid atau tanggal jatuh tempo lebih awal dari tanggal pinjam.');
            $q=$this->pdo->prepare("UPDATE peminjaman SET tanggal_jatuh_tempo=? WHERE id_peminjaman=? AND status_peminjaman='dipinjam'");$q->execute([$due,$id]);$this->pdo->commit();
        }catch(Throwable $e){if($this->pdo->inTransaction())$this->pdo->rollBack();throw $e;}
    }
}
