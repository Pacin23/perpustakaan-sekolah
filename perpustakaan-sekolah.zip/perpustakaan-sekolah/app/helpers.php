<?php
declare(strict_types=1);
if (session_status() === PHP_SESSION_NONE) session_start();
function e(mixed $value): string { return htmlspecialchars((string)$value, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function redirect(string $location): never { header('Location: '.$location); exit; }
function csrf_token(): string {
    if (empty($_SESSION['_csrf_token'])) $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf_token'];
}
function csrf_field(): string { return '<input type="hidden" name="_token" value="'.e(csrf_token()).'">'; }
function verify_csrf(): void {
    $sent=(string)($_POST['_token']??''); $known=(string)($_SESSION['_csrf_token']??'');
    if ($sent==='' || $known==='' || !hash_equals($known,$sent)) { http_response_code(419); exit('Sesi formulir tidak valid. Muat ulang halaman.'); }
}
function flash_set(string $type,string $message): void { $_SESSION['_flash'][$type]=$message; }
function flash_get(string $type): ?string {
    if (!isset($_SESSION['_flash'][$type])) return null;
    $m=(string)$_SESSION['_flash'][$type]; unset($_SESSION['_flash'][$type]); return $m;
}
function format_tanggal(?string $date): string { if(!$date)return '-'; $t=strtotime($date); return $t?date('d-m-Y',$t):e($date); }
function valid_date(string $v): bool { $d=DateTimeImmutable::createFromFormat('!Y-m-d',$v); return $d!==false && $d->format('Y-m-d')===$v; }
