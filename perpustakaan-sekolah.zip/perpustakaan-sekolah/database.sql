CREATE DATABASE IF NOT EXISTS perpustakaan_sekolah CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE perpustakaan_sekolah;

CREATE TABLE IF NOT EXISTS petugas (
 id_petugas INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nama_petugas VARCHAR(100) NOT NULL,
 username VARCHAR(50) NOT NULL,
 password_hash VARCHAR(255) NOT NULL,
 peran ENUM('admin','petugas') NOT NULL DEFAULT 'petugas',
 status_aktif TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uk_petugas_username (username)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS anggota (
 id_anggota INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 no_anggota VARCHAR(20) NOT NULL,
 nama_anggota VARCHAR(100) NOT NULL,
 kelas VARCHAR(30) NULL,
 no_telepon VARCHAR(20) NULL,
 alamat TEXT NULL,
 tanggal_daftar DATE NOT NULL,
 status_anggota ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
 UNIQUE KEY uk_anggota_no (no_anggota),
 KEY idx_anggota_nama (nama_anggota)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS kategori_buku (
 id_kategori INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nama_kategori VARCHAR(100) NOT NULL,
 deskripsi VARCHAR(255) NULL,
 UNIQUE KEY uk_kategori_nama (nama_kategori)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS buku (
 id_buku INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 kode_buku VARCHAR(20) NOT NULL,
 judul VARCHAR(150) NOT NULL,
 penulis VARCHAR(100) NOT NULL,
 penerbit VARCHAR(100) NULL,
 tahun_terbit SMALLINT UNSIGNED NULL,
 isbn VARCHAR(20) NULL,
 id_kategori INT UNSIGNED NOT NULL,
 stok_total SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 stok_tersedia SMALLINT UNSIGNED NOT NULL DEFAULT 0,
 rak VARCHAR(30) NULL,
 status_buku ENUM('tersedia','nonaktif') NOT NULL DEFAULT 'tersedia',
 UNIQUE KEY uk_buku_kode (kode_buku),
 UNIQUE KEY uk_buku_isbn (isbn),
 KEY idx_buku_judul (judul),
 CONSTRAINT fk_buku_kategori FOREIGN KEY (id_kategori) REFERENCES kategori_buku(id_kategori)
 ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS peminjaman (
 id_peminjaman INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 kode_peminjaman VARCHAR(20) NOT NULL,
 id_anggota INT UNSIGNED NOT NULL,
 id_petugas INT UNSIGNED NOT NULL,
 tanggal_pinjam DATE NOT NULL,
 tanggal_jatuh_tempo DATE NOT NULL,
 tanggal_kembali DATE NULL,
 status_peminjaman ENUM('dipinjam','dikembalikan') NOT NULL DEFAULT 'dipinjam',
 UNIQUE KEY uk_peminjaman_kode (kode_peminjaman),
 KEY idx_peminjaman_status_tempo (status_peminjaman, tanggal_jatuh_tempo),
 CONSTRAINT fk_peminjaman_anggota FOREIGN KEY (id_anggota) REFERENCES anggota(id_anggota)
 ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_peminjaman_petugas FOREIGN KEY (id_petugas) REFERENCES petugas(id_petugas)
 ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS detail_peminjaman (
 id_detail INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_peminjaman INT UNSIGNED NOT NULL,
 id_buku INT UNSIGNED NOT NULL,
 jumlah SMALLINT UNSIGNED NOT NULL,
 UNIQUE KEY uk_detail_transaksi_buku (id_peminjaman, id_buku),
 CONSTRAINT fk_detail_peminjaman FOREIGN KEY (id_peminjaman) REFERENCES peminjaman(id_peminjaman)
 ON UPDATE CASCADE ON DELETE RESTRICT,
 CONSTRAINT fk_detail_buku FOREIGN KEY (id_buku) REFERENCES buku(id_buku)
 ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

INSERT IGNORE INTO kategori_buku (nama_kategori,deskripsi) VALUES
('Pemrograman','Buku pemrograman dan pengembangan perangkat lunak'),
('Jaringan Komputer','Buku jaringan dan server'),('Novel','Karya fiksi dan sastra'),
('Pengetahuan Umum','Buku pengetahuan umum');

INSERT IGNORE INTO anggota (no_anggota,nama_anggota,kelas,no_telepon,alamat,tanggal_daftar,status_anggota) VALUES
('AGT-2026-001','Alya Putri','XII PPLG 1','081234560001','Bekasi','2026-07-20','aktif'),
('AGT-2026-002','Bima Pratama','XII PPLG 1','081234560002','Bekasi','2026-07-21','aktif'),
('AGT-2026-003','Citra Lestari','XII TJKT 1','081234560003','Bekasi','2026-07-22','nonaktif');

INSERT IGNORE INTO buku (kode_buku,judul,penulis,penerbit,tahun_terbit,isbn,id_kategori,stok_total,stok_tersedia,rak,status_buku)
SELECT 'BK-PPLG-001','Dasar-Dasar Pemrograman','Tim PPLG','Edukasi',2024,NULL,id_kategori,5,5,'A-01','tersedia'
FROM kategori_buku WHERE nama_kategori='Pemrograman';
INSERT IGNORE INTO buku (kode_buku,judul,penulis,penerbit,tahun_terbit,isbn,id_kategori,stok_total,stok_tersedia,rak,status_buku)
SELECT 'BK-JRK-001','Dasar Jaringan Komputer','Andi Wijaya','Informatika',2023,NULL,id_kategori,3,3,'B-01','tersedia'
FROM kategori_buku WHERE nama_kategori='Jaringan Komputer';
