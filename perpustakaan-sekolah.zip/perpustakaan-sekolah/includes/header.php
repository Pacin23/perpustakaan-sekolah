<?php
require_once __DIR__.'/../app/helpers.php'; require_once __DIR__.'/../app/Auth.php';
$user=Auth::currentUser();$successMessage=flash_get('success');$errorMessage=flash_get('error');
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?=e($pageTitle??'Perpustakaan Sekolah')?></title><link rel="stylesheet" href="assets/style.css"></head><body>
<header class="topbar"><a class="brand" href="index.php"><span class="brand-mark">P</span><span>Perpustakaan<span class="brand-sub">Sistem Peminjaman Buku</span></span></a>
<nav class="nav"><a href="index.php">Dashboard</a><a href="buku.php">Buku</a><a href="kategori.php">Kategori</a><a href="anggota.php">Anggota</a><a href="peminjaman.php">Peminjaman</a><a href="laporan.php">Laporan</a></nav>
<div class="user-area"><span><?=e($user['nama_petugas']??'Petugas')?></span><form action="logout.php" method="post" class="inline-form"><?=csrf_field()?><button class="btn btn-outline btn-sm">Keluar</button></form></div></header>
<main class="container">
<?php if($successMessage):?><div class="alert alert-success"><?=e($successMessage)?></div><?php endif;?>
<?php if($errorMessage):?><div class="alert alert-error"><?=e($errorMessage)?></div><?php endif;?>
