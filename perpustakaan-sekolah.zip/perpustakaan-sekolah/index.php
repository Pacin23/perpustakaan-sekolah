<?php
declare(strict_types=1);require_once __DIR__.'/config/database.php';require_once __DIR__.'/app/helpers.php';require_once __DIR__.'/app/Auth.php';Auth::requireLogin();
$pdo=Database::connection();$counts=[
'buku'=>(int)$pdo->query("SELECT COUNT(*) FROM buku WHERE status_buku='tersedia'")->fetchColumn(),
'anggota'=>(int)$pdo->query("SELECT COUNT(*) FROM anggota WHERE status_anggota='aktif'")->fetchColumn(),
'pinjam'=>(int)$pdo->query("SELECT COUNT(*) FROM peminjaman WHERE status_peminjaman='dipinjam'")->fetchColumn(),
'terlambat'=>(int)$pdo->query("SELECT COUNT(*) FROM peminjaman WHERE status_peminjaman='dipinjam' AND tanggal_jatuh_tempo<CURDATE()")->fetchColumn()];
$recent=$pdo->query("SELECT p.id_peminjaman,p.kode_peminjaman,p.tanggal_pinjam,p.tanggal_jatuh_tempo,p.status_peminjaman,a.nama_anggota FROM peminjaman p JOIN anggota a ON a.id_anggota=p.id_anggota ORDER BY p.id_peminjaman DESC LIMIT 8")->fetchAll();
$pageTitle='Dashboard Perpustakaan';require __DIR__.'/includes/header.php';?>
<div class="page-head"><div><p class="eyebrow">RINGKASAN</p><h1>Dashboard</h1><p>Ringkasan operasional perpustakaan sekolah.</p></div><a class="btn" href="peminjaman_form.php">＋ Transaksi peminjaman</a></div>
<div class="stats"><?php foreach(['buku'=>'Judul buku aktif','anggota'=>'Anggota aktif','pinjam'=>'Belum dikembalikan','terlambat'=>'Terlambat'] as $k=>$label):?><div class="stat"><span><?=$label?></span><strong><?=$counts[$k]?></strong></div><?php endforeach;?></div>
<section class="card"><div class="section-head"><div><h2>Transaksi terbaru</h2><p>Delapan transaksi terakhir yang tercatat.</p></div><a class="text-link" href="peminjaman.php">Lihat semua →</a></div><div class="table-wrap"><table><thead><tr><th>Kode</th><th>Anggota</th><th>Tanggal pinjam</th><th>Jatuh tempo</th><th>Status</th></tr></thead><tbody><?php foreach($recent as $r):?><tr><td><?=e($r['kode_peminjaman'])?></td><td><?=e($r['nama_anggota'])?></td><td><?=format_tanggal($r['tanggal_pinjam'])?></td><td><?=format_tanggal($r['tanggal_jatuh_tempo'])?></td><td><span class="badge"><?=e($r['status_peminjaman'])?></span></td></tr><?php endforeach;?><?php if(!$recent):?><tr><td colspan="5" class="empty">Belum ada transaksi peminjaman.</td></tr><?php endif;?></tbody></table></div></section>
<?php require __DIR__.'/includes/footer.php';?>
