<?php
declare(strict_types=1);require_once __DIR__.'/app/helpers.php';require_once __DIR__.'/app/Auth.php';
if($_SERVER['REQUEST_METHOD']!=='POST')redirect('index.php');verify_csrf();Auth::logout();redirect('login.php');
