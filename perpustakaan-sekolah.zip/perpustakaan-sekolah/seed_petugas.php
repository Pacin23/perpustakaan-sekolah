<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(403);exit("Jalankan melalui terminal.\n");}
require_once __DIR__.'/config/database.php';
$pdo=Database::connection();$username='admin';$password='Perpus@123';
$q=$pdo->prepare('SELECT id_petugas FROM petugas WHERE username=?');$q->execute([$username]);
if($q->fetch()){echo "Akun admin sudah tersedia.\n";exit;}
$q=$pdo->prepare('INSERT INTO petugas(nama_petugas,username,password_hash,peran,status_aktif) VALUES(?,?,?,?,1)');
$q->execute(['Administrator Perpustakaan',$username,password_hash($password,PASSWORD_DEFAULT),'admin']);
echo "Akun dibuat. Username: admin | Password: Perpus@123\nHapus file seed_petugas.php setelah digunakan.\n";
