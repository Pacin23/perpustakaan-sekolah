<?php
declare(strict_types=1);require_once __DIR__.'/config/database.php';
try{Database::connection()->query('SELECT 1');echo 'Koneksi database berhasil.';}
catch(Throwable $e){error_log($e->getMessage());echo 'Koneksi gagal. Periksa konfigurasi database dan layanan MySQL/MariaDB.';}
